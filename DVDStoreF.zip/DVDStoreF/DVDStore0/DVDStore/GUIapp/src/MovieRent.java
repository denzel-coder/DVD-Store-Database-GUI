import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Denzel
 */
public class MovieRent extends javax.swing.JFrame {

    /**
     * Creates new form MovieRent
     */
    public MovieRent() {
        initComponents();
        // allows to center the window
        this.setLocationRelativeTo(null);
        
        // selecting an empty element cancels the filter
        jComboPayement.addItem("");
        jComboPayement.addItem("Cash");
        jComboPayement.addItem("Card");
        // select the first element which corresponds to the empty element
        jComboPayement.setSelectedIndex(0);

       /////////// fill customer combo
       
        // define a connection type variable
        Connection conClient;
        // open a connection
        MyConnection mconClient = new MyConnection();
        
        conClient = mconClient.returnConnection();
        
        // query to display all default clients when opening the window
        
        String sqlquery = "SELECT Customer.FName+' '+Customer.LName AS Customer FROM Customer ORDER BY 1 ";
        // define statement
        Statement stmtClient;
        // define resultset
        ResultSet rsClient;
        try {
            // create statement
            stmtClient = conClient.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            // Runs the given SQL statement and returns a single ResultSet object.
            rsClient = stmtClient.executeQuery(sqlquery);
            
            // selecting an empty element cancels the filter
            jComboClient.addItem("");
            // read all records
            while (rsClient.next()) {
                // fill the combo
                jComboClient.addItem(rsClient.getString("Customer"));
            }
            // close connection, statement, resultset
            rsClient.close();
            stmtClient.close();
            conClient.close(); 

                    } catch (SQLException ex) {
            Logger.getLogger(SearchCustomer.class.getName()).log(Level.SEVERE, null, ex);
        }
       
        // select the first element which corresponds to the empty element
        jComboClient.setSelectedIndex(0);
        // jComboClient.setEditable(true);
       
       /////////// fill Movie combo
       // the same thing
        Connection conMovie;
        MyConnection mconMovie = new MyConnection();
        conMovie = mconMovie.returnConnection();
        
        sqlquery = "SELECT Title FROM Inventory ORDEr BY 1 ";
        Statement stmtMovie;
        ResultSet rsMovie;
        try {
            stmtMovie = conMovie.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            // Runs the given SQL statement and returns a single ResultSet object.
            rsMovie = stmtMovie.executeQuery(sqlquery);
            
            // selecting an empty element cancels the filter
            jComboMovie.addItem("");
            
            while (rsMovie.next()) {
                jComboMovie.addItem(rsMovie.getString("Title"));
            }
            rsMovie.close();
            stmtMovie.close();
            conMovie.close(); 

                    } catch (SQLException ex) {
            Logger.getLogger(SearchCustomer.class.getName()).log(Level.SEVERE, null, ex);
        }
       
        // select the first element which corresponds to the empty element
        jComboMovie.setSelectedIndex(0);
        // jComboMovie.setEditable(true);

       /////////// fill Staff combo
       // the same thing 
        Connection conStaff;
        MyConnection mconStaff = new MyConnection();
        conStaff = mconStaff.returnConnection();
        
        sqlquery = "SELECT FName+' '+LName AS Staff FROM Staff ORDER BY 1 ";
        Statement stmtStaff;
        ResultSet rsStaff;
        try {
            stmtStaff = conStaff.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            // Runs the given SQL statement and returns a single ResultSet object.
            rsStaff = stmtStaff.executeQuery(sqlquery);
            
            // selecting an empty element cancels the filter
            jComboStaff.addItem("");
            while (rsStaff.next()) {
                jComboStaff.addItem(rsStaff.getString("Staff"));
            }
            rsStaff.close();
            stmtStaff.close();
            conStaff.close(); 

                    } catch (SQLException ex) {
            Logger.getLogger(SearchCustomer.class.getName()).log(Level.SEVERE, null, ex);
        }
       
        // select the first element which corresponds to the empty element
        jComboStaff.setSelectedIndex(0);
        // jComboClient.setEditable(true);
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel3 = new javax.swing.JLabel();
        jComboClient = new javax.swing.JComboBox();
        jLabel4 = new javax.swing.JLabel();
        jComboMovie = new javax.swing.JComboBox();
        jLabel5 = new javax.swing.JLabel();
        jComboStaff = new javax.swing.JComboBox();
        jLabel6 = new javax.swing.JLabel();
        jComboPayement = new javax.swing.JComboBox();
        jButtonRent = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        CancelBtn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel3.setText("Client :  ");

        jLabel4.setText("Movie : ");

        jComboMovie.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboMovieActionPerformed(evt);
            }
        });

        jLabel5.setText("Staff :");

        jComboStaff.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboStaffActionPerformed(evt);
            }
        });

        jLabel6.setText("Payement :");

        jComboPayement.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboPayementActionPerformed(evt);
            }
        });

        jButtonRent.setText("ADD Rent");
        jButtonRent.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonRentActionPerformed(evt);
            }
        });

        jPanel6.setBackground(new java.awt.Color(0, 102, 153));
        jPanel6.setForeground(new java.awt.Color(0, 102, 153));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("DVD Rental Store - Rent");
        jLabel8.setAlignmentY(0.4F);

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(9, 9, 9))
        );

        CancelBtn.setText("Back");
        CancelBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(79, 79, 79)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4)
                            .addComponent(jLabel3))
                        .addGap(12, 12, 12)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jComboMovie, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboStaff, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboPayement, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboClient, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(CancelBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 219, Short.MAX_VALUE)
                        .addComponent(jButtonRent, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jComboClient, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jComboMovie, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jComboStaff, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jComboPayement, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 74, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonRent)
                    .addComponent(CancelBtn))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jComboMovieActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboMovieActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboMovieActionPerformed

    private void jComboStaffActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboStaffActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboStaffActionPerformed

    private void jComboPayementActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboPayementActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboPayementActionPerformed

    private void jButtonRentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonRentActionPerformed
        // TODO add your handling code here:

        String TheMessage = "";
        // you cannot add a new rental without the presence of this information
        
        if ("".equals((String)jComboClient.getSelectedItem()))
        {
            TheMessage = "you must select a client\n";
        }

        if ("".equals((String)jComboMovie.getSelectedItem()))
        {
            TheMessage = TheMessage + "you must select a Movie\n";
        }
        if ("".equals((String)jComboStaff.getSelectedItem()))
        {
            TheMessage = TheMessage + "you must select a Staff\n";
        }
        
        if ("".equals((String)jComboPayement.getSelectedItem()))
        {
            TheMessage = TheMessage + "you must select a Payement Type\n";
        }
        
        // 
        if (!"".equals(TheMessage))
        {
            //////////////////// ERROR there is missing information

            javax.swing.JOptionPane.showMessageDialog(null,"To add a rental :\n" + TheMessage);
        }
        else
        {
            // no missing information
            ///////////////////// SEARCH ID MOVIE
            
            // the insertion in the table must be done with the IDs, 
            // it is for this reason that we must seek the ids which corresponds to the selected information
            // to search for the id of the selected film from its title
            String IdMovie="";
            
            Connection ConnIdMovie;
            MyConnection mconIdMovie = new MyConnection();
            ConnIdMovie = mconIdMovie.returnConnection();
            
            String sqlqueryMovie = "Select InventoryID from Inventory WHErE Title='" + (String)jComboMovie.getSelectedItem() + "'";
            Statement stmtIdMovie;
            ResultSet rsIdMovie;
            try {
                stmtIdMovie = ConnIdMovie.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
                // Runs the given SQL statement and returns a single ResultSet object.
                rsIdMovie = stmtIdMovie.executeQuery(sqlqueryMovie);
                while (rsIdMovie.next()) {
                    IdMovie=rsIdMovie.getString("InventoryID");
                }
                rsIdMovie.close();
                stmtIdMovie.close();
                ConnIdMovie.close();

            } catch (SQLException ex) {
                Logger.getLogger(SearchCustomer.class.getName()).log(Level.SEVERE, null, ex);
            }
            java.lang.System.err.println("ID Movie" + IdMovie);

            ///////////////////// SEARCH ID Customer
            String IdClient="";
            Connection ConnIdClient;
            MyConnection mconIdClient = new MyConnection();
            ConnIdClient = mconIdClient.returnConnection();
            String sqlqueryClient = "Select CustomerID from Customer WHErE FName+' '+LName='" + (String)jComboClient.getSelectedItem() + "'";
            //java.lang.System.err.println(sqlqueryClient);
            Statement stmtIdClient;
            ResultSet rsIdClient;
            try {
                stmtIdClient = ConnIdClient.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
                // Runs the given SQL statement and returns a single ResultSet object.
                rsIdClient = stmtIdClient.executeQuery(sqlqueryClient);
                while (rsIdClient.next()) {
                    IdClient=rsIdClient.getString("CustomerID");
                }
                rsIdClient.close();
                stmtIdClient.close();
                ConnIdClient.close();

            } catch (SQLException ex) {
                Logger.getLogger(SearchCustomer.class.getName()).log(Level.SEVERE, null, ex);
            }
            java.lang.System.err.println("ID Client" + IdClient);

            ///////////////////// SEARCH ID Staff
            String IdStaff="";
            Connection ConnIdStaff;
            MyConnection mconIdStaff = new MyConnection();
            ConnIdStaff = mconIdStaff.returnConnection();
            String sqlqueryStaff = "Select StaffID from Staff WHErE FName+ ' '+LName='" + (String)jComboStaff.getSelectedItem() + "'";
            //java.lang.System.err.println(sqlqueryStaff);
            Statement stmtIdStaff;
            ResultSet rsIdStaff;
            try {
                stmtIdStaff = ConnIdStaff.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
                // Runs the given SQL statement and returns a single ResultSet object.
                rsIdStaff = stmtIdStaff.executeQuery(sqlqueryStaff);
                while (rsIdStaff.next()) {
                    IdStaff=rsIdStaff.getString("StaffID");
                }
                rsIdStaff.close();
                stmtIdStaff.close();
                ConnIdStaff.close();

            } catch (SQLException ex) {
                Logger.getLogger(SearchCustomer.class.getName()).log(Level.SEVERE, null, ex);
            }
            java.lang.System.err.println("ID Staff" + IdStaff);

            // we have retrieved all the necessary IDs
            
            ///////////////////// ADD RENT
            PreparedStatement ps = null;
            Statement stmt2 = null;

            Connection ConnInsert;
            MyConnection mconinsert = new MyConnection();
            ConnInsert = mconinsert.returnConnection();
            
            // Query for the insertion of a new rental
            String SQLQueryInsert = "Insert into Rentels "
            + "(LatestUpdate,InventoryID,PaymentType,Barcode,CustomerID,StaffID) "
            + "values ('Rented'," + IdMovie + ",'" + (String)jComboPayement.getSelectedItem()
            + "','',"
            + IdClient + "," + IdStaff + ")";

            java.lang.System.err.println(SQLQueryInsert);
            try {
                ps = ConnInsert.prepareStatement(SQLQueryInsert);
                stmt2 = ConnInsert.createStatement();
                // execution of the query
                ps.executeUpdate();
                ConnInsert.close();

                javax.swing.JOptionPane.showMessageDialog(null,"Rental successfully added");
                
                // the insertion is finished, we must empty the fields
                // select the first element which corresponds to the empty element
                jComboClient.setSelectedIndex(0);
                jComboMovie.setSelectedIndex(0);
                jComboStaff.setSelectedIndex(0);
                jComboPayement.setSelectedIndex(0);

            } catch (SQLException ex) {
                Logger.getLogger(SearchCustomer.class.getName()).log(Level.SEVERE, null, ex);
            }

            java.lang.System.err.println(SQLQueryInsert);


        }

        ///////////FIN
    }//GEN-LAST:event_jButtonRentActionPerformed

    private void CancelBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelBtnActionPerformed
        // TODO add your handling code here:
        System h1=new System();
        h1.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_CancelBtnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MovieRent.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MovieRent.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MovieRent.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MovieRent.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MovieRent().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton CancelBtn;
    private javax.swing.JButton jButtonRent;
    private javax.swing.JComboBox jComboClient;
    private javax.swing.JComboBox jComboMovie;
    private javax.swing.JComboBox jComboPayement;
    private javax.swing.JComboBox jComboStaff;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel6;
    // End of variables declaration//GEN-END:variables
}
