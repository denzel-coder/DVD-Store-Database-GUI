
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Denzel
 */
public class MovieReturn extends javax.swing.JFrame {

    /**
     * Creates new form MovieReturn
     */
    public MovieReturn() {
        
        initComponents();

        // allows to center the window
        this.setLocationRelativeTo(null);
        
        // add an empty element to the combo box
        jComboPayement.addItem("");
        jComboPayement.addItem("Cash");
        jComboPayement.addItem("Card");
        // select the first element which corresponds to the empty element
        jComboPayement.setSelectedIndex(0);

       /////////// fill customer combo
        
        // define a variable of type "connection"
        Connection conClient;
        // open connection
        MyConnection mconClient = new MyConnection();
        conClient = mconClient.returnConnection();
        
        // query to read first and last names of clients
        String sqlquery = "SELECT Customer.FName+' '+Customer.LName AS Customer FROM Customer ORDER BY 1 ";
        Statement stmtClient;
        // result sets
        ResultSet rsClient;
        try {
            stmtClient = conClient.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            // Runs the given SQL statement and returns a single ResultSet object.
            rsClient = stmtClient.executeQuery(sqlquery);
            
            // add an empty element to the combo box 
            // empty element used to cancel a filter
            jComboClient.addItem("");
            
            // loop on the lines of the result set
            while (rsClient.next()) {
                // add an element to the combo
                jComboClient.addItem(rsClient.getString("Customer"));
            }
            // close 
            rsClient.close();
            stmtClient.close();
            conClient.close(); 

                    } catch (SQLException ex) {
            Logger.getLogger(SearchCustomer.class.getName()).log(Level.SEVERE, null, ex);
        }
       
        // select the first element which corresponds to the empty element
        jComboClient.setSelectedIndex(0);
        // jComboClient.setEditable(true);
       
       /////////// fill Movie combo
       
        Connection conMovie;
        MyConnection mconMovie = new MyConnection();
        conMovie = mconMovie.returnConnection();
        
        sqlquery = "SELECT Title FROM Inventory ORDER BY 1 ";
        Statement stmtMovie;
        ResultSet rsMovie;
        try {
            stmtMovie = conMovie.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            // Runs the given SQL statement and returns a single ResultSet object.
            rsMovie = stmtMovie.executeQuery(sqlquery);
            
            // add an empty element to the combo box
            // empty element used to cancel a filter
            jComboMovie.addItem("");
            
            while (rsMovie.next()) {
                jComboMovie.addItem(rsMovie.getString("Title"));
            }
            rsMovie.close();
            stmtMovie.close();
            conMovie.close(); 

                    } catch (SQLException ex) {
            Logger.getLogger(SearchCustomer.class.getName()).log(Level.SEVERE, null, ex);
        }
       // select the first element which corresponds to the empty element
        jComboMovie.setSelectedIndex(0);
        // jComboMovie.setEditable(true);

       /////////// fill Staff combo
       
        Connection conStaff;
        MyConnection mconStaff = new MyConnection();
        conStaff = mconStaff.returnConnection();
        
        sqlquery = "SELECT FName+' '+LName AS Staff FROM Staff ORDER BY 1 ";
        Statement stmtStaff;
        ResultSet rsStaff;
        try {
            stmtStaff = conStaff.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            // Runs the given SQL statement and returns a single ResultSet object.
            rsStaff = stmtStaff.executeQuery(sqlquery);
            
            // add an empty element to the combo box
            // empty element used to cancel a filter
            jComboStaff.addItem("");
            while (rsStaff.next()) {
                jComboStaff.addItem(rsStaff.getString("Staff"));
            }
            rsStaff.close();
            stmtStaff.close();
            conStaff.close(); 

                    } catch (SQLException ex) {
            Logger.getLogger(SearchCustomer.class.getName()).log(Level.SEVERE, null, ex);
        }
       
        // select the first element which corresponds to the empty element
        jComboStaff.setSelectedIndex(0);
        // jComboClient.setEditable(true);
       
        
        ////////// READ ALLL RENTEL 
        Connection con;
        MyConnection mcon = new MyConnection();
        con = mcon.returnConnection();
        
        sqlquery = "SELECT Rentels.RentelID, Rentels.RentalDate, Rentels.ReturnDate, " 
                + " Inventory.Title, " 
                + "Customer.FName+' '+Customer.LName AS Customer, Customer.ContactNumber, " 
                + "Staff.FName+' '+Staff.LName AS Staff, Staff.ContactNumber, Store.StoreName " 
                + " FROM Store " 
                + " INNER JOIN (Staff INNER JOIN (Inventory INNER JOIN (Customer INNER JOIN Rentels ON Customer.CustomerID = Rentels.CustomerID) " 
                + " ON Inventory.InventoryID = Rentels.InventoryID) " 
                + " ON Staff.StaffID = Rentels.StaffID) " 
                + " ON Store.StoreID = Staff.StoreID "
                + " WHERE Rentels.ReturnDate is null "
                + " ORDER BY 1 ";
                // READ ONLY Rentels.ReturnDate is null : read rental not returned
        Statement stmt;
        ResultSet rs;
        try {
            stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            // Runs the given SQL statement and returns a single ResultSet object.
            rs = stmt.executeQuery(sqlquery);
            // fill in the table
            jTableRent.setModel(DbUtils.resultSetToTableModel(rs) );
            rs.close();
            stmt.close();
            con.close(); 

                    } catch (SQLException ex) {
            Logger.getLogger(SearchCustomer.class.getName()).log(Level.SEVERE, null, ex);
        }
        /////////// END READ DATA
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTableRent = new javax.swing.JTable();
        jRentingID = new javax.swing.JTextField();
        jComboClient = new javax.swing.JComboBox();
        jComboMovie = new javax.swing.JComboBox();
        jComboStaff = new javax.swing.JComboBox();
        jComboPayement = new javax.swing.JComboBox();
        CancelBtnSearch = new javax.swing.JButton();
        jButtonRent = new javax.swing.JButton();
        CancelBtn = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTableRent.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTableRent.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableRentMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTableRent);

        jComboMovie.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboMovieActionPerformed(evt);
            }
        });

        jComboStaff.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboStaffActionPerformed(evt);
            }
        });

        jComboPayement.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboPayementActionPerformed(evt);
            }
        });

        CancelBtnSearch.setText("Search");
        CancelBtnSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelBtnSearchActionPerformed(evt);
            }
        });

        jButtonRent.setText("Return Movie");
        jButtonRent.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonRentActionPerformed(evt);
            }
        });

        CancelBtn.setText("Back");
        CancelBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelBtnActionPerformed(evt);
            }
        });

        jLabel6.setText("Payement :");

        jLabel5.setText("Staff :");

        jLabel4.setText("Movie : ");

        jLabel3.setText("Client :  ");

        jLabel2.setText("Renting ID : ");

        jPanel6.setBackground(new java.awt.Color(0, 102, 153));
        jPanel6.setForeground(new java.awt.Color(0, 102, 153));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("DVD Rental Store - Return Movie");
        jLabel8.setAlignmentY(0.4F);

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(CancelBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(CancelBtnSearch, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboPayement, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboMovie, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboClient, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboStaff, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButtonRent, javax.swing.GroupLayout.DEFAULT_SIZE, 142, Short.MAX_VALUE)
                            .addComponent(jRentingID, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 774, Short.MAX_VALUE)
                .addContainerGap())
            .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(jRentingID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jComboClient, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(jComboMovie, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jComboStaff, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jComboPayement, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6))
                        .addGap(18, 18, 18)
                        .addComponent(CancelBtnSearch)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButtonRent)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 172, Short.MAX_VALUE)
                        .addComponent(CancelBtn))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jComboMovieActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboMovieActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboMovieActionPerformed

    private void jComboStaffActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboStaffActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboStaffActionPerformed

    private void jComboPayementActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboPayementActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboPayementActionPerformed

    private void CancelBtnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelBtnSearchActionPerformed
        // TODO add your handling code here:

        ////////// READ DATA when user clic search 
        Connection con;
        MyConnection mcon = new MyConnection();
        con = mcon.returnConnection();
        
        // query takes into account filters an rentals not returned
        String sqlquery = "SELECT Rentels.RentelID,  Rentels.RentalDate, Rentels.ReturnDate, "
        + " Inventory.Title, "
        + "Customer.FName+' '+Customer.LName AS Customer, Customer.ContactNumber, "
        + "Staff.FName+' '+Staff.LName AS Staff, Staff.ContactNumber, Store.StoreName "
        + " FROM Store "
        + " INNER JOIN (Staff INNER JOIN (Inventory INNER JOIN (Customer INNER JOIN Rentels ON Customer.CustomerID = Rentels.CustomerID) "
        + " ON Inventory.InventoryID = Rentels.InventoryID) "
        + " ON Staff.StaffID = Rentels.StaffID) "
        + " ON Store.StoreID = Staff.StoreID "
        + " WHERE Customer.FName+' '+Customer.LName like '" + (String)jComboClient.getSelectedItem() + "%'"
        + " AND Inventory.Title like '" + (String)jComboMovie.getSelectedItem() + "%'"
        + " AND Staff.FName+' '+Staff.LName like '" + (String)jComboStaff.getSelectedItem() + "%'"
        + " AND Rentels.RentelID like '" + jRentingID.getText() + "%'"
        + " AND Rentels.PaymentType like '" + (String)jComboPayement.getSelectedItem() + "%'"
        + " AND Rentels.ReturnDate is null "
        + " ORDER BY 1 ";

        Statement stmt;
        ResultSet rs;
        try {
            stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            // Runs the given SQL statement and returns a single ResultSet object.
            rs = stmt.executeQuery(sqlquery);
            jTableRent.setModel(DbUtils.resultSetToTableModel(rs) );
            rs.close();
            stmt.close();
            con.close();

        } catch (SQLException ex) {
            Logger.getLogger(SearchCustomer.class.getName()).log(Level.SEVERE, null, ex);
        }
        /////////// END READ DATA
    }//GEN-LAST:event_CancelBtnSearchActionPerformed

    private void jButtonRentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonRentActionPerformed
        // TODO add your handling code here:

        String TheMessage = "";

        if ("".equals((String)jRentingID.getText()))
        {
            TheMessage = TheMessage + "You must select a Rental from table or enter the id\n";
        }

        if (!"".equals(TheMessage))
        {
            //////////////////// ERROR

            javax.swing.JOptionPane.showMessageDialog(null, TheMessage);
        }
        else
        {

            int n = JOptionPane.showConfirmDialog(
            null,
            "Are you sure to return this movie ?","Return movie",JOptionPane.YES_NO_OPTION);

             if(n==JOptionPane.YES_OPTION){

            ///////////////////// UPDATE RENT
            PreparedStatement ps = null;
            Statement stmt2 = null;

            Connection ConnInsert;
            MyConnection mconinsert = new MyConnection();
            ConnInsert = mconinsert.returnConnection();
            
            /*
            // create a java calendar instance
            Calendar calendar = Calendar.getInstance();

            // get a java date (java.util.Date) from the Calendar instance.
            // this java date will represent the current date, or "now".
            java.util.Date currentDate = calendar.getTime
            */
            
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            Date date = new Date();
            // query  to return a movie, update LatestUpdate and ReturnDate, 
            // before returning movie the ReturnDate is null
            // after returning movie the ReturnDate have a date
            String SQLQueryInsert = "Update Rentels set LatestUpdate='In Store'" 
                    + ",ReturnDate='" + dateFormat.format(date) 
                    + "' Where RentelID =" + jRentingID.getText() ;

            java.lang.System.err.println(SQLQueryInsert);
            try {
                ps = ConnInsert.prepareStatement(SQLQueryInsert);
                stmt2 = ConnInsert.createStatement();
                // execute query
                ps.executeUpdate();
                ConnInsert.close();

                javax.swing.JOptionPane.showMessageDialog(null,"Rental successfully Updated");
                
                jRentingID.setText("");

            } catch (SQLException ex) {
                Logger.getLogger(SearchCustomer.class.getName()).log(Level.SEVERE, null, ex);
            }

            java.lang.System.err.println(SQLQueryInsert);

            ///////////////////// REFRESH DATA

            Connection con;
            MyConnection mcon = new MyConnection();
            con = mcon.returnConnection();
            
            String sqlquery = "SELECT Rentels.RentelID, Rentels.RentalDate, Rentels.ReturnDate, " 
                + " Inventory.Title, " 
                + "Customer.FName+' '+Customer.LName AS Customer, Customer.ContactNumber, " 
                + "Staff.FName+' '+Staff.LName AS Staff, Staff.ContactNumber, Store.StoreName " 
                + " FROM Store " 
            + " INNER JOIN (Staff INNER JOIN (Inventory INNER JOIN (Customer INNER JOIN Rentels ON Customer.CustomerID = Rentels.CustomerID) "
            + " ON Inventory.InventoryID = Rentels.InventoryID) "
            + " ON Staff.StaffID = Rentels.StaffID) "
            + " ON Store.StoreID = Staff.StoreID "
            + " WHERE Customer.FName+' '+Customer.LName like '" + (String)jComboClient.getSelectedItem() + "%'"
            + " AND Inventory.Title like '" + (String)jComboMovie.getSelectedItem() + "%'"
            + " AND Staff.FName+' '+Staff.LName like '" + (String)jComboStaff.getSelectedItem() + "%'"
            + " AND Rentels.RentelID like '" + jRentingID.getText() + "%'" 
            + " AND Rentels.ReturnDate is null "
            + " ORDER BY 1 ";

            Statement stmt;
            ResultSet rs;
            try {
                stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
                // Runs the given SQL statement and returns a single ResultSet object.
                rs = stmt.executeQuery(sqlquery);
                jTableRent.setModel(DbUtils.resultSetToTableModel(rs) );
                rs.close();
                stmt.close();
                con.close();

            } catch (SQLException ex) {
                Logger.getLogger(SearchCustomer.class.getName()).log(Level.SEVERE, null, ex);
            }
            /////////// END READ DATA

        }
        }
        ///////////END
    }//GEN-LAST:event_jButtonRentActionPerformed

    private void CancelBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelBtnActionPerformed
        // TODO add your handling code here:
        System h1=new System();
        h1.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_CancelBtnActionPerformed

    private void jTableRentMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableRentMouseClicked
        // TODO add your handling code here:

        DefaultTableModel model = (DefaultTableModel)jTableRent.getModel(); 
        int row = jTableRent.getSelectedRow();
        String val0=((String) model.getValueAt(row, 0).toString());
        jRentingID.setText(val0);

    }//GEN-LAST:event_jTableRentMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MovieReturn.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MovieReturn.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MovieReturn.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MovieReturn.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MovieReturn().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton CancelBtn;
    private javax.swing.JButton CancelBtnSearch;
    private javax.swing.JButton jButtonRent;
    private javax.swing.JComboBox jComboClient;
    private javax.swing.JComboBox jComboMovie;
    private javax.swing.JComboBox jComboPayement;
    private javax.swing.JComboBox jComboStaff;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JTextField jRentingID;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTableRent;
    // End of variables declaration//GEN-END:variables
}
