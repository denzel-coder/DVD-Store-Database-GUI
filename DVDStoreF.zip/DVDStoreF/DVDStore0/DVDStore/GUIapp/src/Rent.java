
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.proteanit.sql.DbUtils;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Denzel
 */
public class Rent extends javax.swing.JFrame {

    /**
     * Creates new form Rent
     */
    public Rent() {
        initComponents();
        // allows to center the window
        this.setLocationRelativeTo(null);
        
        // selecting an empty element cancels the filter
        jComboPayement.addItem("");
        jComboPayement.addItem("Cash");
        jComboPayement.addItem("Card");
        // select the first element which corresponds to the empty element
        jComboPayement.setSelectedIndex(0);

       /////////// fill customer combo
       
        Connection conClient;
        MyConnection mconClient = new MyConnection();
        conClient = mconClient.returnConnection();
        
        String sqlquery = "SELECT Customer.FName+' '+Customer.LName AS Customer FROM Customer order by 1";
        Statement stmtClient;
        ResultSet rsClient;
        try {
            stmtClient = conClient.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            // Runs the given SQL statement and returns a single ResultSet object.
            rsClient = stmtClient.executeQuery(sqlquery);
            
            // selecting an empty element cancels the filter
            jComboClient.addItem("");
            while (rsClient.next()) {
                jComboClient.addItem(rsClient.getString("Customer"));
            }
            rsClient.close();
            stmtClient.close();
            conClient.close(); 

                    } catch (SQLException ex) {
            Logger.getLogger(SearchCustomer.class.getName()).log(Level.SEVERE, null, ex);
        }
       // select the first element which corresponds to the empty element
        jComboClient.setSelectedIndex(0);
        // jComboClient.setEditable(true);
       
       /////////// fill Movie combo
       
        Connection conMovie;
        MyConnection mconMovie = new MyConnection();
        conMovie = mconMovie.returnConnection();
        
        sqlquery = "SELECT Title FROM Inventory order by 1";
        Statement stmtMovie;
        ResultSet rsMovie;
        try {
            stmtMovie = conMovie.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            // Runs the given SQL statement and returns a single ResultSet object.
            rsMovie = stmtMovie.executeQuery(sqlquery);
            
            // selecting an empty element cancels the filter
            jComboMovie.addItem("");
            
            while (rsMovie.next()) {
                jComboMovie.addItem(rsMovie.getString("Title"));
            }
            rsMovie.close();
            stmtMovie.close();
            conMovie.close(); 

                    } catch (SQLException ex) {
            Logger.getLogger(SearchCustomer.class.getName()).log(Level.SEVERE, null, ex);
        }
       // select the first element which corresponds to the empty element
        jComboMovie.setSelectedIndex(0);
        // jComboMovie.setEditable(true);

       /////////// fill Staff combo
       
        Connection conStaff;
        MyConnection mconStaff = new MyConnection();
        conStaff = mconStaff.returnConnection();
        
        sqlquery = "SELECT FName+' '+LName AS Staff FROM Staff order by 1";
        Statement stmtStaff;
        ResultSet rsStaff;
        try {
            stmtStaff = conStaff.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            // Runs the given SQL statement and returns a single ResultSet object.
            rsStaff = stmtStaff.executeQuery(sqlquery);
            
            // selecting an empty element cancels the filter
            jComboStaff.addItem("");
            while (rsStaff.next()) {
                jComboStaff.addItem(rsStaff.getString("Staff"));
            }
            rsStaff.close();
            stmtStaff.close();
            conStaff.close(); 

                    } catch (SQLException ex) {
            Logger.getLogger(SearchCustomer.class.getName()).log(Level.SEVERE, null, ex);
        }
       // select the first element which corresponds to the empty element
        jComboStaff.setSelectedIndex(0);
        // jComboClient.setEditable(true);
       
        
        ////////// READ DATA
        Connection con;
        MyConnection mcon = new MyConnection();
        con = mcon.returnConnection();
        
        sqlquery = "SELECT Rentels.RentelID, Rentels.LatestUpdate, Rentels.RentalDate, Rentels.ReturnDate, " 
                + "Inventory.Format, Inventory.Category, Inventory.Title, " 
                + "Customer.FName+' '+Customer.LName AS Customer, Customer.ContactNumber, " 
                + "Staff.FName+' '+Staff.LName AS Staff, Staff.ContactNumber, Store.StoreName " 
              + " FROM Store " 
                + " INNER JOIN (Staff INNER JOIN (Inventory INNER JOIN (Customer INNER JOIN Rentels ON Customer.CustomerID = Rentels.CustomerID) " 
                + " ON Inventory.InventoryID = Rentels.InventoryID) " 
                + " ON Staff.StaffID = Rentels.StaffID) " 
                + " ON Store.StoreID = Staff.StoreID "
                + " ORDER BY 1";

        Statement stmt;
        ResultSet rs;
        try {
            stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            // Runs the given SQL statement and returns a single ResultSet object.
            rs = stmt.executeQuery(sqlquery);
            jTableRent.setModel(DbUtils.resultSetToTableModel(rs) );
            rs.close();
            stmt.close();
            con.close(); 

                    } catch (SQLException ex) {
            Logger.getLogger(SearchCustomer.class.getName()).log(Level.SEVERE, null, ex);
        }
        /////////// END READ DATA
        

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jComboMovie = new javax.swing.JComboBox();
        jTextField1 = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jButtonRent = new javax.swing.JButton();
        CancelBtn = new javax.swing.JButton();
        jComboClient = new javax.swing.JComboBox();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableRent = new javax.swing.JTable();
        CancelBtnSearch = new javax.swing.JButton();
        jComboStaff = new javax.swing.JComboBox();
        jLabel5 = new javax.swing.JLabel();
        jComboPayement = new javax.swing.JComboBox();
        jLabel6 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jComboMovie.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboMovieActionPerformed(evt);
            }
        });

        jLabel2.setText("Renting ID : ");

        jLabel3.setText("Client :  ");

        jLabel4.setText("Movie : ");

        jButtonRent.setText("ADD Rent");
        jButtonRent.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonRentActionPerformed(evt);
            }
        });

        CancelBtn.setText("Back");
        CancelBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelBtnActionPerformed(evt);
            }
        });

        jTableRent.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTableRent);

        CancelBtnSearch.setText("Search");
        CancelBtnSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelBtnSearchActionPerformed(evt);
            }
        });

        jComboStaff.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboStaffActionPerformed(evt);
            }
        });

        jLabel5.setText("Staff :");

        jComboPayement.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboPayementActionPerformed(evt);
            }
        });

        jLabel6.setText("Payement :");

        jPanel6.setBackground(new java.awt.Color(0, 102, 153));
        jPanel6.setForeground(new java.awt.Color(0, 102, 153));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("DVD Rental Store - Rent");
        jLabel8.setAlignmentY(0.4F);

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(9, 9, 9))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(75, 75, 75)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(jLabel4))
                            .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(CancelBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(CancelBtnSearch, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboPayement, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboMovie, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboClient, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboStaff, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButtonRent, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 142, Short.MAX_VALUE))))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 734, Short.MAX_VALUE)
                .addContainerGap())
            .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jComboClient, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(jComboMovie, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jComboStaff, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jComboPayement, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6))
                        .addGap(18, 18, 18)
                        .addComponent(CancelBtnSearch)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButtonRent)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 77, Short.MAX_VALUE)
                        .addComponent(CancelBtn))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void CancelBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelBtnActionPerformed
        // TODO add your handling code here:
        System h1=new System();
        h1.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_CancelBtnActionPerformed

    private void jComboMovieActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboMovieActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboMovieActionPerformed

    private void CancelBtnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelBtnSearchActionPerformed
        // TODO add your handling code here:

        ////////// READ DATA
        Connection con;
        MyConnection mcon = new MyConnection();
        con = mcon.returnConnection();
        
        String sqlquery = "SELECT Rentels.RentelID, Rentels.LatestUpdate, Rentels.RentalDate, Rentels.ReturnDate, " 
                + "Inventory.Format, Inventory.Category, Inventory.Title, " 
                + "Customer.FName+' '+Customer.LName AS Customer, Customer.ContactNumber, " 
                + "Staff.FName+' '+Staff.LName AS Staff, Staff.ContactNumber, Store.StoreName " 
              + " FROM Store " 
                + " INNER JOIN (Staff INNER JOIN (Inventory INNER JOIN (Customer INNER JOIN Rentels ON Customer.CustomerID = Rentels.CustomerID) " 
                + " ON Inventory.InventoryID = Rentels.InventoryID) " 
                + " ON Staff.StaffID = Rentels.StaffID) " 
                + " ON Store.StoreID = Staff.StoreID " 
                + " WHERE Customer.FName+' '+Customer.LName like '" + (String)jComboClient.getSelectedItem() + "%'"
                + " AND Inventory.Title like '" + (String)jComboMovie.getSelectedItem() + "%'"
                + " AND Staff.FName+' '+Staff.LName like '" + (String)jComboStaff.getSelectedItem() + "%'"
                + " AND Rentels.RentelID like '" + jTextField1.getText() + "%'"
                + " AND Rentels.PaymentType like '" + (String)jComboPayement.getSelectedItem() + "%'"
                + " ORDER BY 1";
                
        Statement stmt;
        ResultSet rs;
        try {
            stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            // Runs the given SQL statement and returns a single ResultSet object.
            rs = stmt.executeQuery(sqlquery);
            jTableRent.setModel(DbUtils.resultSetToTableModel(rs) );
            rs.close();
            stmt.close();
            con.close(); 

                    } catch (SQLException ex) {
            Logger.getLogger(SearchCustomer.class.getName()).log(Level.SEVERE, null, ex);
        }
        /////////// END READ DATA
    }//GEN-LAST:event_CancelBtnSearchActionPerformed

    private void jComboStaffActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboStaffActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboStaffActionPerformed

    private void jButtonRentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonRentActionPerformed
        // TODO add your handling code here:
    
    String TheMessage = "";
   
    if ("".equals((String)jComboClient.getSelectedItem()))
        { 
            TheMessage = "you must select a client\n";
        }
    
    if ("".equals((String)jComboMovie.getSelectedItem())) 
        {
            TheMessage = TheMessage + "you must select a Movie\n";
        }
    if ("".equals((String)jComboStaff.getSelectedItem()))
        {   
            TheMessage = TheMessage + "you must select a Staff\n";
        }
    if (!"".equals(jTextField1.getText()))
        { 
            TheMessage = TheMessage + "The filed ID must be empty\n";
        }
    if ("".equals((String)jComboPayement.getSelectedItem())) 
        {
            TheMessage = TheMessage + "you must select a Payement Type\n";
        }

        if (!"".equals(TheMessage))
        { 
            //////////////////// ERROR
            
            javax.swing.JOptionPane.showMessageDialog(null,"To add a rental :\n" + TheMessage);
        }
        else
        {
            ///////////////////// SEARCH ID MOVIE
            String IdMovie="";
            Connection ConnIdMovie;
            MyConnection mconIdMovie = new MyConnection();
            ConnIdMovie = mconIdMovie.returnConnection();
            String sqlqueryMovie = "Select InventoryID from Inventory WHErE Title='" + (String)jComboMovie.getSelectedItem() + "'";
        Statement stmtIdMovie;
        ResultSet rsIdMovie;
        try {
            stmtIdMovie = ConnIdMovie.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            // Runs the given SQL statement and returns a single ResultSet object.
            rsIdMovie = stmtIdMovie.executeQuery(sqlqueryMovie);
            while (rsIdMovie.next()) {
                IdMovie=rsIdMovie.getString("InventoryID");
            }
            rsIdMovie.close();
            stmtIdMovie.close();
            ConnIdMovie.close(); 

                    } catch (SQLException ex) {
            Logger.getLogger(SearchCustomer.class.getName()).log(Level.SEVERE, null, ex);
        }
        java.lang.System.err.println("ID Movie" + IdMovie);

            ///////////////////// SEARCH ID Customer
            String IdClient="";
            Connection ConnIdClient;
            MyConnection mconIdClient = new MyConnection();
            ConnIdClient = mconIdClient.returnConnection();
            String sqlqueryClient = "Select CustomerID from Customer WHErE FName+' '+LName='" + (String)jComboClient.getSelectedItem() + "'";
            //java.lang.System.err.println(sqlqueryClient);
        Statement stmtIdClient;
        ResultSet rsIdClient;
        try {
            stmtIdClient = ConnIdClient.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            // Runs the given SQL statement and returns a single ResultSet object.
            rsIdClient = stmtIdClient.executeQuery(sqlqueryClient);
            while (rsIdClient.next()) {
                IdClient=rsIdClient.getString("CustomerID");
            }
            rsIdClient.close();
            stmtIdClient.close();
            ConnIdClient.close(); 

                    } catch (SQLException ex) {
            Logger.getLogger(SearchCustomer.class.getName()).log(Level.SEVERE, null, ex);
        }
        java.lang.System.err.println("ID Client" + IdClient);        
           
            ///////////////////// SEARCH ID Staff
            String IdStaff="";
            Connection ConnIdStaff;
            MyConnection mconIdStaff = new MyConnection();
            ConnIdStaff = mconIdStaff.returnConnection();
            String sqlqueryStaff = "Select StaffID from Staff WHErE FName+ ' '+LName='" + (String)jComboStaff.getSelectedItem() + "'";
            //java.lang.System.err.println(sqlqueryStaff);
        Statement stmtIdStaff;
        ResultSet rsIdStaff;
        try {
            stmtIdStaff = ConnIdStaff.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            // Runs the given SQL statement and returns a single ResultSet object.
            rsIdStaff = stmtIdStaff.executeQuery(sqlqueryStaff);
            while (rsIdStaff.next()) {
                IdStaff=rsIdStaff.getString("StaffID");
            }
            rsIdStaff.close();
            stmtIdStaff.close();
            ConnIdStaff.close(); 

                    } catch (SQLException ex) {
            Logger.getLogger(SearchCustomer.class.getName()).log(Level.SEVERE, null, ex);
        }
        java.lang.System.err.println("ID Staff" + IdStaff);        

        ///////////////////// ADD RENT
            PreparedStatement ps = null;
            Statement stmt2 = null;
            
            Connection ConnInsert;
            MyConnection mconinsert = new MyConnection();
            ConnInsert = mconinsert.returnConnection();
            
            String SQLQueryInsert = "Insert into Rentels " 
                    + "(LatestUpdate,InventoryID,PaymentType,Barcode,CustomerID,StaffID) "
                    + "values ('Rented'," + IdMovie + ",'" + (String)jComboPayement.getSelectedItem() 
                    + "',''," 
                    + IdClient + "," + IdStaff + ")";
            
            java.lang.System.err.println(SQLQueryInsert);        
            try {
            ps = ConnInsert.prepareStatement(SQLQueryInsert);
            stmt2 = ConnInsert.createStatement();
            ps.executeUpdate();
            ConnInsert.close();
            
            javax.swing.JOptionPane.showMessageDialog(null,"Rental successfully added");
            
                        } catch (SQLException ex) {
                Logger.getLogger(SearchCustomer.class.getName()).log(Level.SEVERE, null, ex);
            }

            java.lang.System.err.println(SQLQueryInsert);        
        
            ///////////////////// REFESH DATA
            
            Connection con;
            MyConnection mcon = new MyConnection();
            con = mcon.returnConnection();
            
            String sqlquery = "SELECT Rentels.RentelID, Rentels.LatestUpdate, Rentels.RentalDate, Rentels.ReturnDate, "
                    + "Inventory.Format, Inventory.Category, Inventory.Title, "
                    + "Customer.FName+' '+Customer.LName AS Customer, Customer.ContactNumber, "
                    + "Staff.FName+' '+Staff.LName AS Staff, Staff.ContactNumber, Store.StoreName "
                    + " FROM Store "
                    + " INNER JOIN (Staff INNER JOIN (Inventory INNER JOIN (Customer INNER JOIN Rentels ON Customer.CustomerID = Rentels.CustomerID) "
                    + " ON Inventory.InventoryID = Rentels.InventoryID) "
                    + " ON Staff.StaffID = Rentels.StaffID) "
                    + " ON Store.StoreID = Staff.StoreID "
                    + " WHERE Customer.FName+' '+Customer.LName like '" + (String)jComboClient.getSelectedItem() + "%'"
                    + " AND Inventory.Title like '" + (String)jComboMovie.getSelectedItem() + "%'"
                    + " AND Staff.FName+' '+Staff.LName like '" + (String)jComboStaff.getSelectedItem() + "%'"
                    + " AND Rentels.RentelID like '" + jTextField1.getText() + "%'"
                    + " ORDER BY 1 ";
            
            Statement stmt;
            ResultSet rs;
            try {
                stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
                // Runs the given SQL statement and returns a single ResultSet object.
                rs = stmt.executeQuery(sqlquery);
                jTableRent.setModel(DbUtils.resultSetToTableModel(rs) );
                rs.close();
                stmt.close();
                con.close();
                
            } catch (SQLException ex) {
                Logger.getLogger(SearchCustomer.class.getName()).log(Level.SEVERE, null, ex);
            }
            /////////// END READ DATA
                        
        }
        
        
        ///////////FIN
    }//GEN-LAST:event_jButtonRentActionPerformed

    private void jComboPayementActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboPayementActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboPayementActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Rent.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Rent.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Rent.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Rent.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Rent().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton CancelBtn;
    private javax.swing.JButton CancelBtnSearch;
    private javax.swing.JButton jButtonRent;
    private javax.swing.JComboBox jComboClient;
    private javax.swing.JComboBox jComboMovie;
    private javax.swing.JComboBox jComboPayement;
    private javax.swing.JComboBox jComboStaff;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTableRent;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}
